$(document).ready(function(){
    
    var test = new Vue({
        el: "#stage",
        data: {
            apple: "ㅋㅋㅋ",
            banana: "ㅎㅎㅎ",
            cherry: 123+123,
            durian: ["짜장면","짬뽕","류산슬"],
            eee: {
                breakfast: {name:"맥모닝", price:4000},
                lunch: {name:"엽떡", price:17000},
                dinner: {name:"파전", price:10000}
            },
            url:{
                naver: "http://naver.com",
                daum: "http://daum.net",
                google: "http://google.com"
            },
            color: ["red","green"],
            img:[
                "images/rabbit.png",
                "images/turtle.png"
            ],
            age: 22,
            vegi: [
                "kale",
                "cucumber",
                "tomato",
                "onion"
            ],
            person: [
                {
                    name:"장동건",
                    age: 19,
                    height: 172
                },
                {
                    name:"원빈",
                    age: 22,
                    height: 180 
                },
                {
                    name:"김태희",
                    age: 32,
                    height: 168
                },
                {
                    name:"슬기",
                    age: 26,
                    height: 162
                }
            ],
            newPerson: {
                name:"",
                age:0,
                height:0
            }
        }, //data의 끝
        methods: {
            addperson: function(){
                this.person.push({
                    name: this.newPerson.name,
                    age: this.newPerson.age,
                    height: this.newPerson.height
                });
            }
        } //methods의 끝
    });// vue객체의 끝
    
    
    test.person.push({
        name: "박나래",
        age: 37,
        height: 148
    });
    
    
    
    
});

















